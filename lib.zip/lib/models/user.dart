class Users {
  final String uid;
  Users({this.uid});
}
